import requests
import logging
import os
from typing import Dict, List

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class RankIconChecker:
    def __init__(self):
        self.base_url = "https://id.embark.games/images/leaderboards/leagues"
        self.save_dir = "rank_icon"
        # 创建保存目录
        if not os.path.exists(self.save_dir):
            os.makedirs(self.save_dir)
            
        # 定义所有段位
        self.ranks: Dict[str, List[str]] = {
            "bronze": ["4", "3", "2", "1"],
            "silver": ["4", "3", "2", "1"],
            "gold": ["4", "3", "2", "1"],
            "platinum": ["4", "3", "2", "1"],
            "diamond": ["4", "3", "2", "1"],
            "ruby": [""]  # Ruby没有子级别
        }
        
    def download_image(self, url: str, filename: str) -> bool:
        """
        下载图片
        :param url: 图片URL
        :param filename: 保存的文件名
        :return: 是否下载成功
        """
        try:
            response = requests.get(url, timeout=5)
            if response.status_code == 200:
                save_path = os.path.join(self.save_dir, filename)
                with open(save_path, 'wb') as f:
                    f.write(response.content)
                logger.info(f"✅ 已保存: {save_path}")
                return True
            return False
        except Exception as e:
            logger.error(f"❌ 下载失败: {str(e)}")
            return False
        
    def check_url(self, url: str) -> bool:
        """
        检查URL是否可访问并下载图片
        :param url: 要检查的URL
        :return: 是否可访问
        """
        try:
            response = requests.head(url, timeout=5)
            if response.status_code == 200:
                logger.info(f"✅ {url} - 200 OK")
                # 获取文件名
                filename = url.split('/')[-1]
                # 下载图片
                self.download_image(url, filename)
                return True
            else:
                logger.error(f"❌ {url} - {response.status_code}")
                return False
        except Exception as e:
            logger.error(f"❌ {url} - 404 (Error: {str(e)})")
            return False
    
    def check_all_ranks(self):
        """检查所有段位图标"""
        logger.info("开始检查段位图标...")
        
        for rank, divisions in self.ranks.items():
            for division in divisions:
                # 构建URL
                if division:
                    url = f"{self.base_url}/{rank}-{division}.png"
                else:
                    url = f"{self.base_url}/{rank}.png"
                
                self.check_url(url)
        
        logger.info("段位图标检查完成")

def main():
    checker = RankIconChecker()
    checker.check_all_ranks()

if __name__ == "__main__":
    main() 